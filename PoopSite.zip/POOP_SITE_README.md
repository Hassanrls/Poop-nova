# Poop Site

This project is a modified version of the uploaded Nova project.

## What changed
- Rebranded the frontend to Poop AI.
- Added an intentionally ugly/funny brown and beige theme.
- Added a visible Poop AI banner.
- Kept the original project structure and backend files intact.
- Existing functionality was not intentionally removed.

The original source files remain in the project so the site can still be developed normally.
